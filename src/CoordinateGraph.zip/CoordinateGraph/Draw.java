package CoordinateGraph;

import java.awt.Graphics;

public class Draw {
	
	private Graphics graphics;
	
	public Draw( Graphics graphics ) {
		this.graphics = graphics;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
