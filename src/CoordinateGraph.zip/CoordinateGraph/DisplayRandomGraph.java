package CoordinateGraph;

public class DisplayRandomGraph {

	public static void main(String[] args) {
		
		CoordinateGraph coordinateGraph = CoordinateGraph.createRandom();
		coordinateGraph.draw();


	}

}
