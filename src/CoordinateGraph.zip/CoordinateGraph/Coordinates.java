package CoordinateGraph;


import java.awt.Graphics;
import java.util.ArrayList;


public class Coordinates {
	
	
	private ArrayList<Coordinate> coordinates = new ArrayList<>();
	
	
	public Coordinates() {
	}
	public Coordinates( Coordinates coordinates ) {
		this.coordinates = coordinates.getCoordinates();
	}


	
	public void add( Coordinate coordinate ) {
		this.coordinates.add( coordinate );
		
	}
	public Coordinate get( int index ) {
		return this.coordinates.get( index );
	}
	public ArrayList<Coordinate> getCoordinates() {
		return this.coordinates;
	}
	
	public int length() {
		return this.coordinates.size();
	}
	
	public void random( int coordinatesLength ) {
		for( int i = 0; i < coordinatesLength; i++ ) {
			add( Coordinate.createRandom() );
		}
	}
	
	public void random( int coordinatesLength, Grid grid ) {
		for( int i = 0; i < coordinatesLength; i++ ) {
			add( Coordinate.createRandom( grid ) );
		}
	}

	public void random( Grid grid ) {
		random( grid.getCoordinatesLimit(), grid );
	}
	
	public void draw( Graphics graphics ) { 
		Coordinates.draw(graphics, this );
	}

	public static void draw( Graphics graphics, Coordinates coordinates ) {
		for( int i = 0; i < coordinates.length(); i++ ) {
			Coordinate coordinate = coordinates.get( i );
			coordinate.draw(graphics);
//			Coordinate.draw(graphics, coordinate);
		}
	}
	public static Coordinates createRandom( Grid grid ) {
		return createRandom( grid.getCoordinatesLimit(), grid );
	}
	public static Coordinates createRandom( int limit, Grid grid ) { 
		Coordinates coords = new Coordinates( );
		for( int index = 0; index < limit; index++ ) {
			Coordinate  randomCoord = Coordinate.createRandom();
			coords.add( randomCoord );
			 
		 }
		return new Coordinates(coords);
	}
	
//	public static void draw(Graphics graphics, Coordinates _coordinates) {
//		Coordinates coordinates = new Coordinates( _coordinates );
//		coordinates.draw(graphics);
//	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
